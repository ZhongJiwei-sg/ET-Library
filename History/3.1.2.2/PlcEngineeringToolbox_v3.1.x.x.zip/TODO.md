# **TODO ET**

## Improvments
- cfCard Diagnose MCP
- Add HMI status byte, buttons and release bit to actuators

## Motion:
- Bst for gantry coupling

## IO:

## New functions:
- FB fuer Rezept handling auf basis - Data base oder XML oder build 4022
- TcpIP Realtime
